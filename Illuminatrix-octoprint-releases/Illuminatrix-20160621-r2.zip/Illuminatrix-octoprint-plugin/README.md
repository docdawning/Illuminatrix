This is the Illuminatrix Octoprint plugin.
